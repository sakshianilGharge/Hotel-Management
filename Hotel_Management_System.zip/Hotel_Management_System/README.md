# Grand Vista Hotel Management System

A ready-to-run beginner-friendly Hotel Management System built with **Python + Streamlit + SQLite**.

## Features
- Responsive hotel website UI with custom CSS, room photos and hotel information
- Home, Rooms & Suites, About, Sign Up, Login, Book a Room, My Bookings pages
- SQLite database is created automatically (`hotel.db`)
- Guest registration and login
- Room booking with check-in/check-out, guest limits and total-price calculation
- Admin dashboard showing registered users, bookings and booking value
- Admin can cancel a booking
- Demo admin login details are displayed on the Login page

## Requirements
- Python 3.10 or newer
- Internet connection for the online hotel photos and Google Fonts (the app itself runs locally)

## Run on Windows
1. Extract `Hotel_Management_System.zip`.
2. Open the extracted `Hotel_Management_System` folder.
3. Click the folder address bar, type `cmd`, and press Enter.
4. Run these commands:

```bash
python -m venv venv
venv\Scripts\activate
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

5. Your browser should open at `http://localhost:8501`. If it doesn't, copy that address into Chrome/Edge.

## Demo administrator
- Email: `admin@grandvista.com`
- Password: `Admin@123`

Create a normal guest account from **Sign Up** to test the user flow.

## Important
This is a college/demo project, not a production hotel booking platform. The hotel address, contact details, rates and guest review score are sample content. Passwords are hashed, but before public deployment use a modern password-hashing library, add CSRF/session protections, validation/rate limiting, backups and proper secrets management. The booking demo does not yet check room inventory/overlapping reservations or process payments.

## Deploy online
This package is ready to run locally. To get a public URL, upload the extracted project to a hosting service such as Streamlit Community Cloud and deploy `app.py`; you will need to sign in to that service and complete deployment there. A public URL cannot be created until the app is deployed to an account.
